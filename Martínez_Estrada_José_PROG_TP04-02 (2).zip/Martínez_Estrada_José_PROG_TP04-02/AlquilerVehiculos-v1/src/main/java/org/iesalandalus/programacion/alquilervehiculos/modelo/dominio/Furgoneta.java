package org.iesalandalus.programacion.alquilervehiculos.modelo.dominio;

public abstract class Furgoneta extends Vehiculo {
private int FACTOR_PMA;
private static int FACTOR_PLAZAS;
private int pma=7000;
private static int plazas;
public Furgoneta(String marca,String modelo,int plazas,String matricula) {
	super(marca, modelo, plazas, matricula);
setPlazas(plazas);
setPma(pma);
}
public Furgoneta(Vehiculo vehiculo) {
super(marca,modelo,matricula,plazas);	
}

public int getPma() {
	return pma;
}
public void setPma(int pma) {
	this.pma = pma;
}
public int getPlazas() {
	return plazas;
}
public void setPlazas(int plazas) {
	this.plazas = plazas;
}

public int getFactorPrecio() {
	return 0;
}

}


