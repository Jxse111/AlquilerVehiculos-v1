package org.iesalandalus.programacion.alquilervehiculos.modelo.negocio;

public interface IFuenteDatos {

	void crearClientes();

	void crearVehiculo();

	void crearAlquileres();

}