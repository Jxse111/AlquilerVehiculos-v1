package org.iesalandalus.programacion.alquilervehiculos.texto;

public enum TipoVehiculo {
TURISMO,FURGONETA,AUTOBUS;
}
