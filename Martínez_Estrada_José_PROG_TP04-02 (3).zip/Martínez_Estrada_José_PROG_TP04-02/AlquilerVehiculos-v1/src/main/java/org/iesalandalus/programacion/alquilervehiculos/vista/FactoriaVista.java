package org.iesalandalus.programacion.alquilervehiculos.vista;

public enum FactoriaVista {
TEXTO;
}
