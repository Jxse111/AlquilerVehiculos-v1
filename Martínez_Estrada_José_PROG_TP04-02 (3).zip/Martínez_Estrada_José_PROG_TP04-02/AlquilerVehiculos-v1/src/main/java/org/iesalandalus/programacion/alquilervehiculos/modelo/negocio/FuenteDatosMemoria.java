package org.iesalandalus.programacion.alquilervehiculos.modelo.negocio;

public class FuenteDatosMemoria implements IFuenteDatos {
@Override
public crearClientes() {
	return IClientes;
}
@Override
public crearVehiculo() {
	return IClientes;
}
@Override
public crearAlquileres() {
	return IAlquileres;
}
}
