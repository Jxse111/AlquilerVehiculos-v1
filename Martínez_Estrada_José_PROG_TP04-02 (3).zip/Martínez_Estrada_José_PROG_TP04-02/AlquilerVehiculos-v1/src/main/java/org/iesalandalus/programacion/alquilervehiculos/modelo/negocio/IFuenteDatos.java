package org.iesalandalus.programacion.alquilervehiculos.modelo.negocio;

public interface IFuenteDatos {

	crearClientes();

	crearVehiculo();

	crearAlquileres();

}