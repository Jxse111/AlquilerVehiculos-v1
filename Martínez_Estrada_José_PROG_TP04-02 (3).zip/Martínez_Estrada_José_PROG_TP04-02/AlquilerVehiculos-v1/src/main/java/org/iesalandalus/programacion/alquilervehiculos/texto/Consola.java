package org.iesalandalus.programacion.alquilervehiculos.texto;

public class Consola {

}
